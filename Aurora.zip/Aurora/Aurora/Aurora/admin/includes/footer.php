<div class="copyrights">
	 <p>© 2023 TMS. All Rights Reserved |  <a href="index.php">Aurora</a> </p>
</div>	
