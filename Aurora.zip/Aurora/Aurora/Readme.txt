Database Configuration

Open phpmyadmin
Create Database tms
Import database tms.sql (available inside zip package)
Open Your browser put inside browser �http://localhost/Aurora�

Login Details for admin : 
Open Your browser put inside browser �http://localhost/Aurora/admin�
Username : admin
Password : admin@123

Login Details for user: 
Open Your browser put inside browser �http://localhost/tms/�
Username : linlin@gmail.com
Password : 123